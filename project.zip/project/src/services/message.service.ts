import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, delay, of } from 'rxjs';

export interface Message {
  id: string;
  sender: string;
  subject: string;
  date: Date;
  status: 'read' | 'unread';
  messageBody: string;
  isAdminReply?: boolean;
  originalMessageId?: string;
  topic?: string;
  email?: string;
  userName?: string;
  accountId?: string;
  serviceId?: string;
  language?: string;
  product?: string;
  environment?: string;
}

export interface ReplyRequest {
  originalMessageId: string;
  replyMessage: string;
  adminEmail: string;
}

export interface SendMessageRequest {
  topic: string;
  subject: string;
  email: string;
  message: string;
  userName: string;
  accountId: string;
  serviceId: string;
  language: string;
  product: string;
  environment: string;
}

@Injectable({
  providedIn: 'root'
})
export class MessageService {
  private messagesSource = new BehaviorSubject<Message[]>([]);
  public messages$ = this.messagesSource.asObservable();

  constructor() {
    // Load messages from localStorage on service initialization
    this.loadMessagesFromStorage();
  }

  private loadMessagesFromStorage(): void {
    const storedMessages = localStorage.getItem('messages');
    if (storedMessages) {
      const messages = JSON.parse(storedMessages).map((msg: any) => ({
        ...msg,
        date: new Date(msg.date)
      }));
      this.messagesSource.next(messages);
    }
  }

  private saveMessagesToStorage(): void {
    const messages = this.messagesSource.value;
    localStorage.setItem('messages', JSON.stringify(messages));
  }

  getMessages(): Observable<Message[]> {
    return this.messages$;
  }

  getMessageById(id: string): Observable<Message | undefined> {
    const messages = this.messagesSource.value;
    const message = messages.find(m => m.id === id);
    return of(message).pipe(delay(100));
  }

  markAsRead(messageId: string): void {
    const messages = this.messagesSource.value;
    const message = messages.find(m => m.id === messageId);
    if (message && message.status === 'unread') {
      message.status = 'read';
      this.messagesSource.next([...messages]);
      this.saveMessagesToStorage();
    }
  }

  sendMessage(messageRequest: SendMessageRequest): Observable<boolean> {
    // Create a new message from the sent message request
    const newMessage: Message = {
      id: this.generateMessageId(),
      sender: messageRequest.email,
      subject: messageRequest.subject,
      date: new Date(),
      status: 'unread',
      messageBody: messageRequest.message,
      isAdminReply: false,
      topic: messageRequest.topic,
      email: messageRequest.email,
      userName: messageRequest.userName,
      accountId: messageRequest.accountId,
      serviceId: messageRequest.serviceId,
      language: messageRequest.language,
      product: messageRequest.product,
      environment: messageRequest.environment
    };

    // Add the new message to the inbox
    const currentMessages = this.messagesSource.value;
    const updatedMessages = [newMessage, ...currentMessages];
    this.messagesSource.next(updatedMessages);
    this.saveMessagesToStorage();
    
    // Simulate API delay
    return of(true).pipe(delay(1000));
  }

  replyToMessage(replyRequest: ReplyRequest): Observable<boolean> {
    const originalMessage = this.messagesSource.value.find(m => m.id === replyRequest.originalMessageId);
    if (!originalMessage) {
      return of(false);
    }

    // Create admin reply message
    const replyMessage: Message = {
      id: this.generateMessageId(),
      sender: `Admin (${replyRequest.adminEmail})`,
      subject: `Re: ${originalMessage.subject}`,
      date: new Date(),
      status: 'unread',
      messageBody: replyRequest.replyMessage,
      isAdminReply: true,
      originalMessageId: replyRequest.originalMessageId,
      topic: originalMessage.topic,
      email: originalMessage.email,
      userName: originalMessage.userName,
      accountId: originalMessage.accountId,
      serviceId: originalMessage.serviceId,
      language: originalMessage.language,
      product: originalMessage.product,
      environment: originalMessage.environment
    };

    // Add the reply to the inbox
    const currentMessages = this.messagesSource.value;
    const updatedMessages = [replyMessage, ...currentMessages];
    this.messagesSource.next(updatedMessages);
    this.saveMessagesToStorage();
    
    return of(true).pipe(delay(500));
  }

  private generateMessageId(): string {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
  }

  getTopics(): string[] {
    return [
      'Account Issues',
      'Transaction Inquiries',
      'Technical Support',
      'General Questions',
      'Billing Questions',
      'Product Information'
    ];
  }

  getLanguages(): string[] {
    return ['English', 'Spanish', 'French', 'German', 'Chinese'];
  }

  getProducts(): string[] {
    return [
      'Checking Account',
      'Savings Account',
      'Credit Card',
      'Loan Services',
      'Investment Services',
      'Online Banking'
    ];
  }

  getEnvironments(): string[] {
    return ['DEV', 'UAT', 'PROD', 'COB'];
  }
}