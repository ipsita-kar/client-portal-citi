import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadComponent: () => import('./components/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: '',
    loadComponent: () => import('./components/layout/layout.component').then(m => m.LayoutComponent),
    canActivate: [AuthGuard],
    children: [
      {
        path: 'home',
        loadComponent: () => import('./components/home/home.component').then(m => m.HomeComponent)
      },
      {
        path: 'send-message',
        loadComponent: () => import('./components/send-message/send-message.component').then(m => m.SendMessageComponent)
      },
      {
        path: 'inbox',
        loadComponent: () => import('./components/inbox/inbox.component').then(m => m.InboxComponent)
      }
    ]
  },
  {
    path: '**',
    redirectTo: '/login'
  }
];