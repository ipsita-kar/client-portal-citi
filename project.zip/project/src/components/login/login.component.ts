import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule
  ],
  template: `
    <div class="centered-container">
      <mat-card class="login-card">
        <mat-card-header>
          <mat-card-title class="login-title">
            <mat-icon class="title-icon">security</mat-icon>
            Kana Secure Messaging Portal
          </mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <form #loginForm="ngForm" (ngSubmit)="onLogin()" class="login-form">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Username</mat-label>
              <input 
                matInput 
                [(ngModel)]="username" 
                name="username" 
                required
                autocomplete="username">
              <mat-icon matSuffix>person</mat-icon>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Password</mat-label>
              <input 
                matInput 
                type="password" 
                [(ngModel)]="password" 
                name="password" 
                required
                autocomplete="current-password">
              <mat-icon matSuffix>lock</mat-icon>
            </mat-form-field>

            <button 
              mat-raised-button 
              color="primary" 
              type="submit"
              class="login-button full-width"
              [disabled]="!loginForm.form.valid || isLoading">
              <mat-icon *ngIf="isLoading">hourglass_empty</mat-icon>
              <span *ngIf="!isLoading">Login</span>
              <span *ngIf="isLoading">Signing in...</span>
            </button>
          </form>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .login-card {
      width: 400px;
      max-width: 90vw;
      padding: 20px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }

    .login-title {
      text-align: center;
      color: #1976d2;
      font-size: 24px;
      font-weight: 500;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
    }

    .title-icon {
      font-size: 28px;
    }

    .login-form {
      margin-top: 20px;
    }

    .login-button {
      margin-top: 16px;
      height: 48px;
      font-size: 16px;
    }

    mat-form-field {
      margin-bottom: 16px;
    }
  `]
})
export class LoginComponent {
  username = '';
  password = '';
  isLoading = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  onLogin(): void {
    if (!this.username || !this.password) {
      this.snackBar.open('Please enter username and password', 'Close', {
        duration: 3000,
        panelClass: ['error-snackbar']
      });
      return;
    }

    this.isLoading = true;

    // Simulate loading delay
    setTimeout(() => {
      const success = this.authService.login(this.username, this.password);
      
      if (success) {
        this.snackBar.open('Login successful!', 'Close', {
          duration: 2000,
          panelClass: ['success-snackbar']
        });
        this.router.navigate(['/home']);
      } else {
        this.snackBar.open('Invalid credentials. Use username: admin, password: kana@citi', 'Close', {
          duration: 3000,
          panelClass: ['error-snackbar']
        });
      }
      
      this.isLoading = false;
    }, 1000);
  }
}