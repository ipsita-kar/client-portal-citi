import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MessageService, SendMessageRequest } from '../../services/message.service';

@Component({
  selector: 'app-send-message',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    MatDividerModule,
    MatProgressBarModule
  ],
  template: `
    <div class="send-message-container">
      <mat-card class="form-card">
        <mat-card-header>
          <mat-card-title class="form-title">
            <mat-icon>send</mat-icon>
            Send a New Message
          </mat-card-title>
        </mat-card-header>

        <mat-progress-bar 
          mode="indeterminate" 
          *ngIf="isSubmitting"
          class="progress-bar">
        </mat-progress-bar>

        <mat-card-content>
          <form #messageForm="ngForm" (ngSubmit)="onSubmit(messageForm)" class="message-form">
            
            <!-- Message Details Section -->
            <h3 class="section-header">
              <mat-icon>message</mat-icon>
              Message Details
            </h3>
            
            <div class="form-row">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Topic</mat-label>
                <mat-select [(ngModel)]="messageData.topic" name="topic" required>
                  <mat-option *ngFor="let topic of topics" [value]="topic">
                    {{ topic }}
                  </mat-option>
                </mat-select>
              </mat-form-field>
            </div>

            <div class="form-row">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Subject</mat-label>
                <input 
                  matInput 
                  [(ngModel)]="messageData.subject" 
                  name="subject" 
                  required
                  maxlength="200">
              </mat-form-field>
            </div>

            <div class="form-row">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Message</mat-label>
                <textarea 
                  matInput 
                  [(ngModel)]="messageData.message" 
                  name="message" 
                  required
                  rows="6"
                  maxlength="2000">
                </textarea>
                <mat-hint align="end">
                  {{ messageData.message?.length || 0 }}/2000
                </mat-hint>
              </mat-form-field>
            </div>

            <mat-divider class="section-divider"></mat-divider>

            <!-- User Information Section -->
            <h3 class="section-header">
              <mat-icon>person</mat-icon>
              User Information
            </h3>

            <div class="form-row">
              <mat-form-field appearance="outline" class="half-width">
                <mat-label>Email</mat-label>
                <input 
                  matInput 
                  type="email"
                  [(ngModel)]="messageData.email" 
                  name="email" 
                  required>
                <mat-icon matSuffix>email</mat-icon>
              </mat-form-field>

              <mat-form-field appearance="outline" class="half-width">
                <mat-label>User Name</mat-label>
                <input 
                  matInput 
                  [(ngModel)]="messageData.userName" 
                  name="userName" 
                  required>
                <mat-icon matSuffix>person</mat-icon>
              </mat-form-field>
            </div>

            <div class="form-row">
              <mat-form-field appearance="outline" class="half-width">
                <mat-label>Account ID</mat-label>
                <input 
                  matInput 
                  [(ngModel)]="messageData.accountId" 
                  name="accountId" 
                  required>
                <mat-icon matSuffix>account_box</mat-icon>
              </mat-form-field>

              <mat-form-field appearance="outline" class="half-width">
                <mat-label>Service ID</mat-label>
                <input 
                  matInput 
                  [(ngModel)]="messageData.serviceId" 
                  name="serviceId" 
                  required>
                <mat-icon matSuffix>room_service</mat-icon>
              </mat-form-field>
            </div>

            <mat-divider class="section-divider"></mat-divider>

            <!-- Configuration Section -->
            <h3 class="section-header">
              <mat-icon>settings</mat-icon>
              Configuration
            </h3>

            <div class="form-row">
              <mat-form-field appearance="outline" class="third-width">
                <mat-label>Language</mat-label>
                <mat-select [(ngModel)]="messageData.language" name="language" required>
                  <mat-option *ngFor="let lang of languages" [value]="lang">
                    {{ lang }}
                  </mat-option>
                </mat-select>
              </mat-form-field>

              <mat-form-field appearance="outline" class="third-width">
                <mat-label>Product</mat-label>
                <mat-select [(ngModel)]="messageData.product" name="product" required>
                  <mat-option *ngFor="let product of products" [value]="product">
                    {{ product }}
                  </mat-option>
                </mat-select>
              </mat-form-field>

              <mat-form-field appearance="outline" class="third-width">
                <mat-label>Environment</mat-label>
                <mat-select [(ngModel)]="messageData.environment" name="environment" required>
                  <mat-option *ngFor="let env of environments" [value]="env">
                    <span [ngClass]="'env-' + env.toLowerCase()">{{ env }}</span>
                  </mat-option>
                </mat-select>
              </mat-form-field>
            </div>

            <div class="form-actions">
              <button 
                mat-raised-button 
                type="button"
                (click)="onReset(messageForm)"
                [disabled]="isSubmitting">
                <mat-icon>clear</mat-icon>
                Reset Form
              </button>

              <button 
                mat-raised-button 
                color="primary" 
                type="submit"
                [disabled]="!messageForm.form.valid || isSubmitting"
                class="send-button">
                <mat-icon *ngIf="!isSubmitting">send</mat-icon>
                <mat-icon *ngIf="isSubmitting">hourglass_empty</mat-icon>
                {{ isSubmitting ? 'Sending...' : 'Send Message' }}
              </button>
            </div>
          </form>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .send-message-container {
      max-width: 900px;
      margin: 0 auto;
      padding: 20px;
    }

    .form-card {
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .form-title {
      display: flex;
      align-items: center;
      gap: 12px;
      color: #1976d2;
      font-size: 24px;
    }

    .progress-bar {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      z-index: 10;
    }

    .message-form {
      margin-top: 20px;
    }

    .section-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 32px 0 16px 0;
      color: #1976d2;
      font-weight: 500;
      font-size: 18px;
    }

    .section-header:first-of-type {
      margin-top: 0;
    }

    .section-divider {
      margin: 32px 0;
    }

    .form-row {
      display: flex;
      gap: 16px;
      margin-bottom: 16px;
    }

    .full-width {
      width: 100%;
    }

    .half-width {
      flex: 1;
    }

    .third-width {
      flex: 1;
    }

    .form-actions {
      display: flex;
      justify-content: space-between;
      margin-top: 32px;
      padding-top: 16px;
      border-top: 1px solid #e0e0e0;
    }

    .send-button {
      min-width: 150px;
    }

    .env-dev {
      color: #4caf50;
      font-weight: 600;
    }

    .env-uat {
      color: #ff9800;
      font-weight: 600;
    }

    .env-prod {
      color: #f44336;
      font-weight: 600;
    }

    .env-cob {
      color: #9c27b0;
      font-weight: 600;
    }

    @media (max-width: 768px) {
      .send-message-container {
        padding: 16px;
      }

      .form-row {
        flex-direction: column;
        gap: 0;
      }

      .half-width,
      .third-width {
        width: 100%;
      }

      .form-actions {
        flex-direction: column;
        gap: 12px;
      }

      .form-actions button {
        width: 100%;
      }
    }
  `]
})
export class SendMessageComponent implements OnInit {
  messageData: SendMessageRequest = {
    topic: '',
    subject: '',
    email: '',
    message: '',
    userName: '',
    accountId: '',
    serviceId: '',
    language: 'English',
    product: '',
    environment: 'DEV'
  };

  topics: string[] = [];
  languages: string[] = [];
  products: string[] = [];
  environments: string[] = [];
  isSubmitting = false;

  constructor(
    private messageService: MessageService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.topics = this.messageService.getTopics();
    this.languages = this.messageService.getLanguages();
    this.products = this.messageService.getProducts();
    this.environments = this.messageService.getEnvironments();
  }

  onSubmit(form: NgForm): void {
    if (!form.valid) {
      this.snackBar.open('Please fill in all required fields', 'Close', {
        duration: 3000,
        panelClass: ['error-snackbar']
      });
      return;
    }

    this.isSubmitting = true;
    
    this.messageService.sendMessage(this.messageData).subscribe({
      next: (success) => {
        if (success) {
          this.snackBar.open('Message sent successfully! Check Customer Inbox to view.', 'Close', {
            duration: 3000,
            panelClass: ['success-snackbar']
          });
          this.onReset(form);
        } else {
          throw new Error('Failed to send message');
        }
      },
      error: (error) => {
        console.error('Error sending message:', error);
        this.snackBar.open('Failed to send message. Please try again.', 'Close', {
          duration: 3000,
          panelClass: ['error-snackbar']
        });
      },
      complete: () => {
        this.isSubmitting = false;
      }
    });
  }

  onReset(form: NgForm): void {
    form.resetForm();
    this.messageData = {
      topic: '',
      subject: '',
      email: '',
      message: '',
      userName: '',
      accountId: '',
      serviceId: '',
      language: 'English',
      product: '',
      environment: 'DEV'
    };
  }
}