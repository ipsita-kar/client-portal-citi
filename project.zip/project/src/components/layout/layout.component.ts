import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { MatSidenavModule, MatSidenav } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable, map } from 'rxjs';
import { AuthService, User } from '../../services/auth.service';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav 
        #drawer 
        class="sidenav" 
        fixedInViewport
        [attr.role]="(isHandset$ | async) ? 'dialog' : 'navigation'"
        [mode]="(isHandset$ | async) ? 'over' : 'side'"
        [opened]="(isHandset$ | async) === false">
        
        <div class="sidenav-header">
          <mat-icon class="sidenav-logo">security</mat-icon>
          <h3>Kana Portal</h3>
        </div>

        <mat-nav-list>
          <a mat-list-item routerLink="/home" routerLinkActive="active-link">
            <mat-icon matListItemIcon>home</mat-icon>
            <span matListItemTitle>Home</span>
          </a>
          
          <a mat-list-item routerLink="/send-message" routerLinkActive="active-link">
            <mat-icon matListItemIcon>send</mat-icon>
            <span matListItemTitle>Send a New Message</span>
          </a>
          
          <a mat-list-item routerLink="/inbox" routerLinkActive="active-link">
            <mat-icon matListItemIcon>inbox</mat-icon>
            <span matListItemTitle>Customer Inbox</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>

      <mat-sidenav-content>
        <mat-toolbar color="primary" class="toolbar">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()"
            *ngIf="isHandset$ | async">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          
          <span class="toolbar-title">Secure Messaging Portal</span>
          
          <div class="toolbar-spacer"></div>
          
          <div class="environment-indicator" *ngIf="!(isHandset$ | async)">
            <span class="environment-badge env-dev">DEV</span>
            <span class="environment-badge env-uat">UAT</span>
            <span class="environment-badge env-prod">PROD</span>
          </div>
          
          <button mat-icon-button [matMenuTriggerFor]="userMenu">
            <mat-icon>account_circle</mat-icon>
          </button>
          
          <mat-menu #userMenu="matMenu">
            <div class="user-info" *ngIf="currentUser$ | async as user">
              <p class="user-name">{{ user.username }}</p>
              <p class="user-email">{{ user.email }}</p>
            </div>
            <mat-divider></mat-divider>
            <button mat-menu-item (click)="logout()">
              <mat-icon>logout</mat-icon>
              <span>Logout</span>
            </button>
          </mat-menu>
        </mat-toolbar>

        <div class="content">
          <router-outlet></router-outlet>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
      background-color: #263238;
      color: white;
    }

    .sidenav-header {
      padding: 20px 16px;
      display: flex;
      align-items: center;
      gap: 12px;
      border-bottom: 1px solid #37474f;
      margin-bottom: 8px;
    }

    .sidenav-logo {
      font-size: 28px;
      color: #4fc3f7;
    }

    .sidenav mat-nav-list {
      padding-top: 0;
    }

    .sidenav mat-list-item {
      color: #b0bec5;
      margin: 4px 8px;
      border-radius: 8px;
    }

    .sidenav mat-list-item:hover {
      background-color: #37474f;
      color: white;
    }

    .sidenav .active-link {
      background-color: #1976d2 !important;
      color: white !important;
    }

    .toolbar {
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .toolbar-title {
      font-weight: 500;
    }

    .toolbar-spacer {
      flex: 1 1 auto;
    }

    .environment-indicator {
      display: flex;
      gap: 8px;
      margin-right: 16px;
    }

    .content {
      padding: 20px;
      min-height: calc(100vh - 64px);
      background-color: #fafafa;
    }

    .user-info {
      padding: 12px 16px;
    }

    .user-name {
      font-weight: 500;
      margin: 0;
    }

    .user-email {
      font-size: 12px;
      color: #666;
      margin: 4px 0 0 0;
    }

    @media (max-width: 768px) {
      .environment-indicator {
        display: none;
      }
      
      .toolbar-title {
        font-size: 16px;
      }
      
      .content {
        padding: 16px;
      }
    }
  `]
})
export class LayoutComponent implements OnInit {
  @ViewChild('drawer') drawer!: MatSidenav;
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(map(result => result.matches));
  
  currentUser$ = this.authService.currentUser$;

  constructor(
    private breakpointObserver: BreakpointObserver,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.authService.checkAuthStatus();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}