import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Message, MessageService } from '../../services/message.service';

@Component({
  selector: 'app-message-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatChipsModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    MatSnackBarModule
  ],
  template: `
    <div class="message-dialog">
      <div mat-dialog-title class="dialog-header">
        <div class="title-content">
          <mat-icon class="message-icon">email</mat-icon>
          <span>Message Details</span>
        </div>
        <button 
          mat-icon-button 
          mat-dialog-close
          class="close-button">
          <mat-icon>close</mat-icon>
        </button>
      </div>

      <div mat-dialog-content class="dialog-content">
        <div class="message-meta">
          <div class="meta-row">
            <div class="meta-label">
              <mat-icon>person</mat-icon>
              From:
            </div>
            <div class="meta-value">{{ data.sender }}</div>
          </div>

          <div class="meta-row">
            <div class="meta-label">
              <mat-icon>subject</mat-icon>
              Subject:
            </div>
            <div class="meta-value">{{ data.subject }}</div>
          </div>

          <div class="meta-row">
            <div class="meta-label">
              <mat-icon>schedule</mat-icon>
              Date:
            </div>
            <div class="meta-value">{{ data.date | date:'full' }}</div>
          </div>

          <div class="meta-row">
            <div class="meta-label">
              <mat-icon>info</mat-icon>
              Status:
            </div>
            <div class="meta-value">
              <mat-chip 
                [ngClass]="'status-chip-' + data.status"
                class="status-chip">
                <mat-icon matChipAvatar>
                  {{ data.status === 'unread' ? 'mark_email_unread' : 'drafts' }}
                </mat-icon>
                {{ data.status | titlecase }}
              </mat-chip>
            </div>
          </div>
        </div>

        <mat-divider class="content-divider"></mat-divider>

        <div class="message-body">
          <h4 class="body-header">
            <mat-icon>message</mat-icon>
            Message Content
          </h4>
          <div class="body-content">
            {{ data.messageBody }}
          </div>
        </div>

        <!-- Reply Section -->
        <div class="reply-section" *ngIf="!data.isAdminReply">
          <mat-divider class="reply-divider"></mat-divider>
          
          <h4 class="reply-header">
            <mat-icon>reply</mat-icon>
            Admin Reply
          </h4>
          
          <div class="reply-form" *ngIf="!showReplyForm">
            <button 
              mat-raised-button 
              color="primary"
              (click)="showReplyForm = true"
              class="show-reply-button">
              <mat-icon>reply</mat-icon>
              Write Reply
            </button>
          </div>

          <div class="reply-form" *ngIf="showReplyForm">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Your Reply</mat-label>
              <textarea 
                matInput 
                [(ngModel)]="replyMessage"
                rows="4"
                maxlength="1000"
                placeholder="Type your reply to the customer...">
              </textarea>
              <mat-hint align="end">{{ replyMessage?.length || 0 }}/1000</mat-hint>
            </mat-form-field>
            
            <div class="reply-actions">
              <button 
                mat-button 
                (click)="cancelReply()"
                [disabled]="isReplying">
                Cancel
              </button>
              
              <button 
                mat-raised-button 
                color="primary"
                (click)="sendReply()"
                [disabled]="!replyMessage?.trim() || isReplying">
                <mat-icon *ngIf="!isReplying">send</mat-icon>
                <mat-icon *ngIf="isReplying">hourglass_empty</mat-icon>
                {{ isReplying ? 'Sending...' : 'Send Reply' }}
              </button>
            </div>
          </div>
        </div>

        <!-- Admin Reply Indicator -->
        <div class="admin-reply-indicator" *ngIf="data.isAdminReply">
          <mat-chip class="admin-chip">
            <mat-icon matChipAvatar>admin_panel_settings</mat-icon>
            Admin Response
          </mat-chip>
        </div>
      </div>

      <div mat-dialog-actions class="dialog-actions">
        <button 
          mat-button 
          mat-dialog-close
          class="cancel-button">
          Close
        </button>
        
        <button
          *ngIf="!data.isAdminReply && !showReplyForm"
          mat-raised-button 
          color="primary"
          (click)="showReplyForm = true">
          <mat-icon>reply</mat-icon>
          Reply
        </button>
      </div>
    </div>
  `,
  styles: [`
    .message-dialog {
      max-width: 100%;
    }

    .dialog-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0;
      padding-bottom: 16px;
      border-bottom: 1px solid #e0e0e0;
    }

    .title-content {
      display: flex;
      align-items: center;
      gap: 12px;
      color: #1976d2;
      font-size: 20px;
      font-weight: 500;
    }

    .message-icon {
      font-size: 24px;
    }

    .close-button {
      color: #666;
    }

    .dialog-content {
      padding: 24px 0;
      max-height: 70vh;
      overflow-y: auto;
    }

    .message-meta {
      margin-bottom: 24px;
    }

    .meta-row {
      display: flex;
      align-items: center;
      margin-bottom: 16px;
      gap: 16px;
    }

    .meta-label {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 100px;
      font-weight: 500;
      color: #333;
    }

    .meta-label mat-icon {
      font-size: 20px;
      color: #666;
    }

    .meta-value {
      flex: 1;
      word-break: break-word;
    }

    .status-chip {
      height: 32px;
    }

    .status-chip-unread {
      background-color: #ffebee;
      color: #c62828;
    }

    .status-chip-read {
      background-color: #e8f5e8;
      color: #2e7d32;
    }

    .content-divider {
      margin: 24px 0;
    }

    .message-body {
      background-color: #fafafa;
      border-radius: 8px;
      padding: 20px;
      border-left: 4px solid #1976d2;
    }

    .body-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0 0 16px 0;
      color: #1976d2;
      font-size: 16px;
      font-weight: 500;
    }

    .body-content {
      line-height: 1.6;
      color: #333;
      white-space: pre-wrap;
      word-break: break-word;
    }

    .reply-section {
      margin-top: 24px;
    }

    .reply-divider {
      margin: 24px 0 16px 0;
    }

    .reply-header {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 0 0 16px 0;
      color: #1976d2;
      font-size: 16px;
      font-weight: 500;
    }

    .reply-form {
      margin-top: 16px;
    }

    .show-reply-button {
      margin-bottom: 16px;
    }

    .full-width {
      width: 100%;
    }

    .reply-actions {
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      margin-top: 16px;
    }

    .admin-reply-indicator {
      margin-top: 16px;
      display: flex;
      justify-content: center;
    }

    .admin-chip {
      background-color: #e3f2fd;
      color: #1976d2;
      font-weight: 500;
    }

    .dialog-actions {
      padding-top: 16px;
      border-top: 1px solid #e0e0e0;
      justify-content: flex-end;
      gap: 12px;
    }

    .cancel-button {
      color: #666;
    }

    @media (max-width: 600px) {
      .dialog-content {
        max-height: 60vh;
      }

      .meta-row {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
      }

      .meta-label {
        min-width: unset;
      }

      .dialog-actions {
        flex-direction: column-reverse;
      }

      .dialog-actions button {
        width: 100%;
      }
    }
  `]
})
export class MessageDialogComponent {
  showReplyForm = false;
  replyMessage = '';
  isReplying = false;

  constructor(
    public dialogRef: MatDialogRef<MessageDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Message,
    private snackBar: MatSnackBar,
    private messageService: MessageService
  ) {}

  sendReply(): void {
    if (!this.replyMessage?.trim()) {
      return;
    }

    this.isReplying = true;
    
    const replyRequest = {
      originalMessageId: this.data.id,
      replyMessage: this.replyMessage.trim(),
      adminEmail: 'admin@company.com'
    };

    this.messageService.replyToMessage(replyRequest).subscribe({
      next: (success) => {
        if (success) {
          this.snackBar.open('Reply sent successfully!', 'Close', {
            duration: 3000,
            panelClass: ['success-snackbar']
          });
          this.dialogRef.close('replied');
        } else {
          throw new Error('Failed to send reply');
        }
      },
      error: (error) => {
        console.error('Error sending reply:', error);
        this.snackBar.open('Failed to send reply. Please try again.', 'Close', {
          duration: 3000,
          panelClass: ['error-snackbar']
        });
      },
      complete: () => {
        this.isReplying = false;
      }
    });
  }

  cancelReply(): void {
    this.showReplyForm = false;
    this.replyMessage = '';
  }
}